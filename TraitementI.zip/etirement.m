function r = etirement(img)
img = double(img);
vmin = double(min(min(img)));
vmax = double(max(max(img)));
[x, y] = size(img);
r = zeros(x, y);
r = double(r);
for i = 1 : y
    for j = 1 : x 
        r(j, i) = 255. * (img(j, i) - vmin)/(vmax - vmin);
    end
end
r = uint8(r);
end