function img = egalisation(img)
img = double(img);
[x, y] = size(img);
hc = hist_cumul(img);

for i = 1 : y
    for j = 1: x
        img(j, i) = 255 * hc(img(j, i));
    end
end
img = uint8(img);
end