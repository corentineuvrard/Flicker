function r = trans(img)
[x, y] = size(img);
res = zeros(x, y);

for i = 1 : y
   for j = 1 : x 
      if img(j, i) < 50
          res(j, i) = res(j, i);
      elseif img(j, i) < 151
          res(j, i) = 255;
      else
          res(j, i) = 255 - img(j, i);
      end
    end
end
end