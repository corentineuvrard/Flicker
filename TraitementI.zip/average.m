function [x, avg] = average(param1, param2)
    size(param1, 1);
    avg = zeros(size(param1, 1), 1);
    for i = 1 : size(param1, 1)
        avg(i) = (param1(i) + param2(i)) / 2;
    end
    x = 0:1:size(param1, 1) - 1;
end
