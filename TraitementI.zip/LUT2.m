function r = LUT()

img = imread('NG/rectangles.bmp');
r = ones(256, 1);
g = ones(256, 1);
b = ones(256, 1);

g(30) = 0;
b(30) = 0;

r(77) = 0;
g(77) = 0;
b(77) = 0;

b(92) = 0;

r(151) = 0;
g(151) = 0;

r(227) = 0;
b(227) = 0;

map4C = [r g b];
image(img);
colormap(map4C)
end
