function r = main()
img1 = imread('imgclaire.jpeg');
img2 = imread('imgfonce.jpeg');
[x1, hist1] = hist_cumul(img1);
[x2, hist2] = hist_cumul(img2);
[x, histavg] = average(hist1, hist2);

subplot(4, 2, 1);
imshow(img1);

subplot(4, 2, 2);
imshow(img2);

subplot(4, 2, 3);
plot(x1, hist1);

subplot(4, 2, 4);
plot(x2, hist2);

subplot(4, 2, 5);
plot(hist1, x1);

subplot(4, 2, 6);
plot(hist2, x2);

subplot(4, 2, 7);
plot(histavg, x);

subplot(4, 2, 8);
plot(histavg);

r = histavg;
end