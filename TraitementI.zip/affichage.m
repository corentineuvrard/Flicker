function r = affichage(I)
subplot(3, 2, 1);
imshow(I);

subplot(3, 2, 2);
imshow(etirement(I));

subplot(3, 2, 3);
plot(histogramme(I));

subplot(3, 2, 4);
plot(histogramme(etirement(I)));

subplot(3, 2, 5);
equation(I);
end