function r = equation(img)
vmin = double(min(min(img)));
vmax = double(max(max(img)));

a = 255. / (vmax - vmin)
b = -255. * vmin /(vmax - vmin)

x = 0:1:255;
y = a * x + b;

plot(x, y);

xlim([0, 256]);
ylim([0, 256]);
end