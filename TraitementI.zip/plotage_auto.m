function s = plotage_auto(img)
seuil = 255 * graythresh(img);
subplot(1, 3, 1);
imshow(img);

subplot(1, 3, 2);
plot(histogramme(img));

subplot(1, 3, 3);
imshow(binarisation(img, seuil));

title(strcat(['Seuil=', num2str(seuil)])); 
end