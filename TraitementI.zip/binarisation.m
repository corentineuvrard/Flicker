function res = binarisation(img, seuil)
res = img > seuil;
end