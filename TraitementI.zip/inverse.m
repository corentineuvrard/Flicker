function inv = inverse(f)
    inv = zeros(size(f, 1), 1);
    x = 0:1:255;
    y = f;
end