function inv = inverse(f)
    inv = zeros(size(f, 1), 1);
    size(f, 1)
    f = round(f);
    for i = 1 : size(f, 1)
        inv(f(i) + 1) = i + 1; 
    end
end